﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingRoomSystem
{
    class Admin:User
    {
        public Admin(string username, string password):base(username, password)
        {
        }
        
    }
}
